package com.example.simpleplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

class MainActivity : Activity() {

    private lateinit var videoView: VideoView
    private lateinit var listView: ListView
    private lateinit var nowPlaying: TextView
    private lateinit var adapter: ArrayAdapter<String>

    private val uris = ArrayList<Uri>()
    private val names = ArrayList<String>()
    private var index = -1
    private var savedPos = -1

    private val pickCode = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Video area (black box; MP3s just show black)
        val videoBox = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        videoView = VideoView(this)
        videoBox.addView(
            videoView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )
        val mc = MediaController(this)
        mc.setAnchorView(videoBox)
        videoView.setMediaController(mc)
        root.addView(
            videoBox,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(230))
        )

        nowPlaying = TextView(this).apply {
            text = "Nothing playing. Tap Add files."
            textSize = 15f
            setPadding(dp(12), dp(10), dp(12), dp(6))
        }
        root.addView(nowPlaying)

        // Buttons row
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun addButton(label: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                setOnClickListener { action() }
            }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        addButton("Prev") { playIndex(index - 1) }
        addButton("Play/Pause") {
            if (index >= 0) {
                if (videoView.isPlaying) videoView.pause() else videoView.start()
            }
        }
        addButton("Next") { playIndex(index + 1) }
        root.addView(row)

        val addBtn = Button(this).apply {
            text = "Add files (MP3 / MP4)"
            setOnClickListener { pickFiles() }
        }
        root.addView(addBtn)

        // Playlist
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, names)
        listView = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_SINGLE
            this.adapter = this@MainActivity.adapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
                playIndex(pos)
            }
        }
        root.addView(
            listView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)

        videoView.setOnCompletionListener {
            if (index + 1 < uris.size) playIndex(index + 1)
        }
        videoView.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Can't play this file", Toast.LENGTH_SHORT).show()
            true
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW && i.data != null) {
            val u = i.data!!
            addUris(listOf(u))
            playIndex(uris.size - 1)
        }
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK || data == null) return

        val picked = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (n in 0 until clip.itemCount) picked.add(clip.getItemAt(n).uri)
        } else if (data.data != null) {
            picked.add(data.data!!)
        }
        if (picked.isEmpty()) return

        val firstNew = uris.size
        addUris(picked)
        if (index == -1) playIndex(firstNew)
    }

    private fun addUris(list: List<Uri>) {
        for (u in list) {
            uris.add(u)
            names.add(nameOf(u))
        }
        adapter.notifyDataSetChanged()
    }

    private fun nameOf(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (n != null) return n
                    }
                }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "Unknown file"
    }

    private fun playIndex(i: Int) {
        if (i < 0 || i >= uris.size) return
        index = i
        videoView.setVideoURI(uris[i])
        videoView.start()
        nowPlaying.text = names[i]
        listView.setItemChecked(i, true)
    }

    override fun onPause() {
        super.onPause()
        savedPos = if (index >= 0) videoView.currentPosition else -1
    }

    override fun onResume() {
        super.onResume()
        if (index >= 0 && savedPos >= 0) {
            videoView.setVideoURI(uris[index])
            videoView.seekTo(savedPos)
            savedPos = -1
        }
    }
}
